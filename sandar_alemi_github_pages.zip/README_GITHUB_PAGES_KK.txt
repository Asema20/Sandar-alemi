# Сандар әлемі — интерактивті ойындар

Қазақ тіліндегі 1–10 көлеміндегі сандарға арналған 6 жеке ойын.

## GitHub Pages арқылы жариялау

1. GitHub аккаунтыңызға кіріңіз: https://github.com
2. New repository басып, репозиторий атауын `sandar-alemi` деп қойыңыз.
3. Public таңдаңыз да, Create repository басыңыз.
4. Осы архивтегі барлық файлды репозиторийге жүктеңіз (Upload files).
5. Commit changes басыңыз.
6. Settings → Pages → Build and deployment бөлімінде `Deploy from a branch` таңдаңыз.
7. Branch ретінде `main`, папка ретінде `/ (root)` таңдап, Save басыңыз.
8. Біраз уақыттан кейін сайт `https://USERNAME.github.io/sandar-alemi/` мекенжайында ашылады.

`USERNAME` орнына GitHub пайдаланушы атыңыз жазылады. Әр ойынның жеке сілтемесі:
- `https://USERNAME.github.io/sandar-alemi/01_sandy_tap.html`
- `https://USERNAME.github.io/sandar-alemi/02_zattardy_sana.html`
- `https://USERNAME.github.io/sandar-alemi/03_sandar_poyizy.html`
- `https://USERNAME.github.io/sandar-alemi/04_korshisyn_tap.html`
- `https://USERNAME.github.io/sandar-alemi/05_zhashyryn_san.html`
- `https://USERNAME.github.io/sandar-alemi/06_salystyr.html`

Басты бет барлық ойынға сілтеме береді: `https://USERNAME.github.io/sandar-alemi/`

Барлық ойын интернетке шыққаннан кейін телефонда, компьютерде және интерактивті тақтада ашылады.
